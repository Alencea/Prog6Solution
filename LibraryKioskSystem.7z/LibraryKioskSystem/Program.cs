﻿

using System.Text.RegularExpressions;

namespace LibraryKioskSystem
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StreamReader sr = new StreamReader(Path.GetFullPath("books.csv"));// gets file file
            string temp = sr.ReadToEnd();// reads in file
            string[] sets = temp.Split("\n");// splits file based on new line
            BinaryNode<Book>[] books = new BinaryNode<Book>[sets.Length];// sets up an array of BinaryNodes with the Book atribute
            Trees.Array_AVL<BinaryNode<Book>> Titles = new Trees.Array_AVL<BinaryNode<Book>>();// sets up an AVL tree with BinaryNodes as nodes
            SortedDictionary<string, Trees.Array_AVL<BinaryNode<Book>>> Authors = new SortedDictionary<string, Trees.Array_AVL<BinaryNode<Book>>>();// sets up a sorted dictionary with strings as keys and AVL trees as values
            SortedDictionary<string, Trees.Array_AVL<BinaryNode<Book>>> Publishers = new SortedDictionary<string, Trees.Array_AVL<BinaryNode<Book>>>();// sets up a sorted dictionary with strings as keys and AVL trees as values
           
            for (int j = 0; j < sets.Length; j++)//for loop then runs through sets
			{

                string[] tempA = sets[j].Split(",");// splits each line of sets at , and puts it in too an array
                Queue<string> tempB = new();// sets up a queue of type string 
                if (tempA.Length >= 4) // checks to make sure that the array is long enough
                { 
                    for (int i = 0; i < tempA.Length; i++)// for loop that runs through the array tempA
                    {
                        string last = "";
                        //ifstatmen to remove spaces
                        if (i+1 < tempA.Length && tempA[i+1].StartsWith(" "))// checks for spaces
                        {
                            string thingOne = Regex.Replace(tempA[i], @"[^0-9a-zA-Z ]+", ""); // removes special characters
                            string thingTwo = Regex.Replace(tempA[i+1], @"[^0-9a-zA-Z ]+", "");// removes special characters
                            last = (thingOne +" "+ thingTwo);// conjoins the string witjh a space to the string before it
                            i++;// incroments i to skip over the used string
                        }
                        else if (!tempB.Contains(tempA[i]))// checks to see if the queue has the string
                        {
                            
                            last = Regex.Replace(tempA[i], @"[^0-9a-zA-Z ]+", "");// removes special characters
                        }
                        tempB.Enqueue(last);// adds the string to the queue
                    }

                    Book book = new Book();// makes a new object of type Book
                    book.Title = tempB.Dequeue();// adds first string from queue tempB to book.Title
                    book.Author = tempB.Dequeue().ToLower();// adds second string from queue tempB to book.Author
                    book.Pages = int.Parse(tempB.Dequeue());// adds third string from queue tempB to book.Pages
                    book.Publisher = tempB.Dequeue().ToLower();// adds first forth from queue tempB to book.Publisher

                    BinaryNode<Book> node = new BinaryNode<Book>();// makes a new BinaryNode with the book atribute
                    node.self = book.Title;// sets the title to be self
                    node.item = book;// adds the book to the node

                    books[j] = node;// adds node to the array books
                    
                }
            
            }

            foreach (BinaryNode<Book> node in books)// runs through books
            {
                if(node != null)// checks if the node is null
                { 
                    if(!String.IsNullOrEmpty(node.self))// checks to see if the string is empty or null
                    {
                        Titles.Add(node);// adds the node to the tree Titles

                    }

                    if(node.item.Author != null)// checks if the nodes author is null
                    { 
                        if (!Authors.ContainsKey(node.item.Author))// checks if the Authors has the author
                        {
                            Trees.Array_AVL<BinaryNode<Book>> newAuthor = new Trees.Array_AVL<BinaryNode<Book>>();// makes a new tree
                            newAuthor.Add(node);// adds the node to the tree
                            Authors.Add(node.item.Author, newAuthor);// adds the tree and to the sorted dictionary as the value and its author as the key
                    
                        }
                        else// else
                        {
                            Authors[node.item.Author].Add(node);// adds the node to the value tree with the same author as the node
                    
                        }
                
                    }

                    if(node.item.Publisher != null) // checks if the nodes author is null
                    { 
                        if (!Publishers.ContainsKey(node.item.Publisher))// checks if the Authors has the author
                        {
                            Trees.Array_AVL<BinaryNode<Book>> newPublisher = new Trees.Array_AVL<BinaryNode<Book>>();// makes a new tree
                            newPublisher.Add(node);// adds the node to the tree
                            Publishers.Add(node.item.Publisher, newPublisher);// adds the tree and to the sorted dictionary as the value and its author as the key
                    
                        }
                        else
                        {
                            Publishers[node.item.Publisher].Add(node);// adds the node to the value tree with the same author as the node
                        
                        }
                    
                    }
                }
            }
	        
            List<BinaryNode<Book>> currentBook = new List<BinaryNode<Book>>();// makes a new list of BinaryNode with the book atribute
            Console.WriteLine("Would you like to checkout a book?");// outputs the first question
            string answer = Console.ReadLine();// reads the line

            while(string.Equals(answer, "yes", StringComparison.OrdinalIgnoreCase) || string.Equals(answer, "y", StringComparison.OrdinalIgnoreCase))// checks to see if the question is answered corectly
            {
                Console.WriteLine("Enter 1 if you know the title.\n Enter 2 you know the Author.\n Enter 3 if you know the publisher.\n Enter anything else to quit.");// output second question
                string nextAnswer = Console.ReadLine();// reads the line
                
                if(nextAnswer == "1")// if answer is one
                {
                    
                    Console.WriteLine("What is the title of the book you are looking for?");// outputs next question
                    nextAnswer = Console.ReadLine();// reads the line

                    
                    string gg = "no";// sets up gg as no to keep loop runing
                    for (int i = 0;!string.Equals(gg, "yes", StringComparison.OrdinalIgnoreCase); i++)// for loop with i loop counter
                    {
                        
                        if (string.Equals(Titles.FindFirst(books[i]).Data.self, nextAnswer, StringComparison.OrdinalIgnoreCase))// checks if title is in the tree
                        {
                            Titles.FindFirst(books[i]).Data.item.Print();// prints the info of the book
                            Console.WriteLine("Is this the book you are looking for?");// outputs next question
                            nextAnswer = Console.ReadLine();// reads the line
                            if(string.Equals(nextAnswer, "yes", StringComparison.OrdinalIgnoreCase) || string.Equals(nextAnswer, "y", StringComparison.OrdinalIgnoreCase))// checks if it is the right book
                            { 
                                currentBook.Add(Titles.FindFirst(books[i]).Data);// gets the book and adds it to currentBook
                                Titles.Remove(Titles.FindFirst(books[i]));// removes book from titles
                                gg = "yes";// sets gg to yes to break out of loop
                            }
                            if(i >= Titles.Count)// checks to see if i is greater than or equal to the number of books in Title
                            {
                                Console.WriteLine("We are sorry that we could not find your book.");// outputs apoligy
                                gg = "yes";// sets gg to yes to break out of loop
                            }
                        }
                        
                    }
			        
                    
                }

                if(nextAnswer == "2")// if answer is two
                {
                    
                    Console.WriteLine("Who is the \"Author\"(\"Lastname Firstname\") of the book you are looking for?");// outputs next question
                    nextAnswer = Console.ReadLine();// reads the line
                    
                    
                    if (Authors.ContainsKey(nextAnswer.ToLower()))// checks if Authors has the nextAnswer as a key 
                    { 
                        Trees.Array_AVL<BinaryNode<Book>> tempAuthor = new Trees.Array_AVL<BinaryNode<Book>>();// makes a new tree
                        tempAuthor = Authors[nextAnswer.ToLower()];// sets the chosen tree to the new tree
                        BinaryNode<Book>[] tempAuthors = tempAuthor.ToArray();// turns the tree into an array

                        for (int i = 1; i <= tempAuthors.Length; i++)// runs through tempAuthors
                        {
                            Console.WriteLine(i + " : " + tempAuthors[i-1].self);//outputs a list of books by the chosen author
                        }
                        
                        int num = -1;// sets up num equal to -1
                        while(num < 0 || num > tempAuthors.Length)// runs while num is less than 0 or while num is greater then the length of tempAuthors
                        { 
                            Console.WriteLine("Please enter the number of the book you would like, or enter 0 if none of these are the book(s) you are looking for.");// outputs next question
                            nextAnswer = Console.ReadLine();// reads the line
                            if(int.TryParse(nextAnswer, out _))// checks to see if the answer is an int
                            { 
                                num = int.Parse(nextAnswer);// parses the answer into num
                            }
                        }
                        string gg = "no";// sets up gg as no to keep loop runing
                        if(num == 0)// checks if num is 0
                            {
                                Console.WriteLine("We are sorry that we could not find your book.");// outputs apoligy
                                gg = "yes";// sets gg to yes to stay out of loop
                            }
                        while (!string.Equals(gg, "yes", StringComparison.OrdinalIgnoreCase))// runs while gg is not yes
                        {
                        
                        
                            Authors[tempAuthors[num - 1].item.Author].FindFirst(tempAuthors[num - 1]).Data.item.Print();// prints the info of the book
                            Console.WriteLine("Is this the book you are looking for?");// outputs next question
                            nextAnswer = Console.ReadLine();// reads the line
                            
                            if(string.Equals(nextAnswer, "yes", StringComparison.OrdinalIgnoreCase) || string.Equals(nextAnswer, "y", StringComparison.OrdinalIgnoreCase))// checks if it is the right book
                            { 
                                currentBook.Add(tempAuthors[num - 1]);// gets the book and adds it to currentBook
                                if(tempAuthors.Length >= 1)// to see if the length of the tree is 1
                                {
                                    Authors[tempAuthors[num - 1].item.Author].Clear();// clears the tree
                                    Authors.Remove(tempAuthors[num - 1].item.Author);// removes the key from Authors
                                }
                                else// else
                                {
                                    Authors[tempAuthors[num - 1].item.Author].Remove(tempAuthors[num - 1]);// removes book from authors tree
                                }
                                
                                gg = "yes";// sets gg to yes to break out of loop
                            }
                            else// else
                            {
                                num = -1;//sets num to -1
                                while(num < 0 || num > tempAuthors.Length)// runs while num is less than 0 or while num is greater then the length of tempAuthors
                                { 
                                    Console.WriteLine("Please enter the number of the book you would like, or enter 0 if none of these are the book(s) you are looking for.");// outputs next question
                                    nextAnswer = Console.ReadLine();// reads the line
                                    if(int.TryParse(nextAnswer, out _))// checks to see if the answer is an int
                                    { 
                                    num = int.Parse(nextAnswer);// parses the answer into num
                                    }
                                }
                            }
                            if(num == 0)// check to see if num is 0
                            {
                                Console.WriteLine("We are sorry that we could not find your book.");// outputs apoligy
                                gg = "yes";// sets gg to yes to break out of loop
                            }
                        
                        
                        }
			        }
                    
                }

                if(nextAnswer == "3")// if answer is three
                {
                    
                    Console.WriteLine("Who is the publisher of the book you are looking for?");// outputs next question
                    nextAnswer = Console.ReadLine();// reads the line
                    
                    
                    if (Publishers.ContainsKey(nextAnswer.ToLower()))// checks if publisher has the nextAnswer as a key 
                    { 
                        Trees.Array_AVL<BinaryNode<Book>> tempPublisher = new Trees.Array_AVL<BinaryNode<Book>>();// makes a new tree
                        tempPublisher = Publishers[nextAnswer.ToLower()];// sets the chosen tree to the new tree
                        BinaryNode<Book>[] tempPublishers = tempPublisher.ToArray();// turns the tree into an array

                        for (int i = 1; i <= tempPublishers.Length; i++)// runs through tempPublishers
                        {
                            Console.WriteLine(i + " : " + tempPublishers[i-1].self);//outputs a list of books of the chosen publisher 
                        }
                        
                        int num = -1;// sets up num equal to -1
                        while(num < 0 || num > tempPublishers.Length)// runs while num is less than 0 or while num is greater then the length of tempPublishers
                        { 
                            Console.WriteLine("Please enter the number of the book you would like, or enter 0 if none of these are the book(s) you are looking for.");// outputs next question
                            nextAnswer = Console.ReadLine();// reads the line
                            if(int.TryParse(nextAnswer, out _))// checks to see if the answer is an int
                            { 
                                num = int.Parse(nextAnswer);// parses the answer into num
                            }
                        }
                        string gg = "no";// sets up gg as no to keep loop runing
                        if(num == 0)// checks if num is 0
                            {
                                Console.WriteLine("We are sorry that we could not find your book.");// outputs apoligy
                                gg = "yes";// sets gg to yes to stay out of loop
                            }
                        while (!string.Equals(gg, "yes", StringComparison.OrdinalIgnoreCase))// runs while gg is not yes
                        {
                        
                        
                            Publishers[tempPublishers[num - 1].item.Publisher].FindFirst(tempPublishers[num - 1]).Data.item.Print();// prints the info of the book
                            Console.WriteLine("Is this the book you are looking for?");// outputs next question
                            nextAnswer = Console.ReadLine();// reads the line
                            
                            if(string.Equals(nextAnswer, "yes", StringComparison.OrdinalIgnoreCase) || string.Equals(nextAnswer, "y", StringComparison.OrdinalIgnoreCase))// checks if it is the right book
                            { 
                                currentBook.Add(tempPublishers[num - 1]);// gets the book and adds it to currentBook
                                if(tempPublishers.Length >= 1)// to see if the length of the tree is 1
                                {
                                    Publishers[tempPublishers[num - 1].item.Publisher].Clear();// clears the tree
                                    Publishers.Remove(tempPublishers[num - 1].item.Publisher);// removes the key from Publishers
                                }
                                else// else
                                {
                                    Publishers[tempPublishers[num - 1].item.Publisher].Remove(tempPublishers[num - 1]);// removes book from publishers tree
                                }
                                
                                gg = "yes";// sets gg to yes to break out of loop
                            }
                            else// else
                            {
                                num = -1;//sets num to -1
                                while(num < 0 || num > tempPublishers.Length)// runs while num is less than 0 or while num is greater then the length of tempPublishers
                                { 
                                    Console.WriteLine("Please enter the number of the book you would like, or enter 0 if none of these are the book(s) you are looking for.");// outputs next question
                                    nextAnswer = Console.ReadLine();// reads the line
                                    if(int.TryParse(nextAnswer, out _))// checks to see if the answer is an int
                                    { 
                                    num = int.Parse(nextAnswer);// parses the answer into num
                                    }
                                }
                            }
                            if(num == 0)// check to see if num is 0
                            {
                                Console.WriteLine("We are sorry that we could not find your book.");// outputs apoligy
                                gg = "yes";// sets gg to yes to break out of loop
                            }
                        
                        
                        }
			        }
                    
                }
                
                Console.WriteLine("Would you like another book?");// outputs next question
                answer = Console.ReadLine();// reads the line


            }
            Console.WriteLine("These are the books you have checked out.");
            foreach (BinaryNode<Book> Books in currentBook)
            {
                Console.WriteLine(Books.self);
            }
            Console.WriteLine("Thank you for working with us.");



        }
        
    }

}