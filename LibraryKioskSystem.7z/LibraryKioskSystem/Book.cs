﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace LibraryKioskSystem
{/// <summary>
/// sets up Book class
/// </summary>
    internal class Book//constructor for Book class
    {
        public string? Title { get; set; }// sets up title variable
        public string? Author { get; set; }// sets up author variable
        public int Pages { get; set; }// sets up pages variable
        public string? Publisher { get; set; }// sets up publisher variable

        public void Print() => Console.WriteLine(this.Title + " by " + this.Author + ", " + this.Pages + " pages, published by " + this.Publisher);// is methode to print out Book info

    }
    
}