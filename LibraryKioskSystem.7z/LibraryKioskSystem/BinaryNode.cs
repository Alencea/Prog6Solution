﻿using System;

namespace LibraryKioskSystem
{/// <summary>
/// sets up BinaryNode class
/// </summary>
/// <typeparam name="T"></typeparam>
    internal class BinaryNode<T> : IComparable// constructor for binaryNode class inherts from IComparable
	{
        public string self { get; set; }// sets up variable self
        public T item { get; set; }// sets up genaric variable item

        //Author: © Microsoft 2022
        //Owner: © Microsoft 2022
        //last edited:  nov 20, 2022 at 8:25
        //got from: https://learn.microsoft.com/en-us/dotnet/api/system.icomparable?view=net-7.0


        public int CompareTo(object obj)
        {
            if (obj == null)
            {
                return 1;
            }
            BinaryNode<T> newBinaryNode = obj as BinaryNode<T>;
            if (newBinaryNode != null)
            {
                return this.self.CompareTo(newBinaryNode.self);
            }
            else
            {
                throw new ArgumentException("Object is not a book");
            }

        }


        

    }
}
